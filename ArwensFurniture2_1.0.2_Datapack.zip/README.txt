Hello! Thanks for trying my datapack. If you like my work please share the PMC page with your friends!
My main goal in creating these datapacks is to share my work with other people, and to help others enjoy Minecraft more.

If you are looking to use this pack in a video, please provide a link to the Planet Minecraft page for the datapack.

If you'd like more furniture, you can install extensions to this datapack through my Planet Minecraft.
The resource pack for this datapack will contain models from exentions of this datapack, and can be enabled by using the extension datapacks.

Have a nice day, and enjoy the furniture,

- Arwen